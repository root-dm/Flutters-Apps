import 'package:flutter/material.dart';
import 'package:database/login-register.dart';

void main() {
  runApp(
    const MaterialApp(
      home: Login(),
    ),
  );
}
